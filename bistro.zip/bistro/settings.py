import torch
import logging


save_model_dir = '/apdcephfs/private_haroldyuan/checkpoints/ssd'
train_root_dir = '/apdcephfs/share_1330077/mingyanzhu/datasets/CloudAI/spp32768_train'
val_root_dir = '/apdcephfs/share_1330077/mingyanzhu/datasets/CloudAI/spp32768_val'
test_image_dir = '/apdcephfs/share_1330077/mingyanzhu/datasets/CloudAI/spp32768_test'
save_image_dir = '/apdcephfs/private_haroldyuan/checkpoints/ssd'

model_name = 'asia-BistroInterior'

recursion_step = 5
epoch_num = 300
tb_record_interval = 10

# ------- param --------------
dilation = False
deform = False
# -----------------------------

train_width = 256
test_width = 512
batch_size = 8
num_workers = 10
best_checkpoint = True
debug = True

resume = False
resume_model_name = 'multiscale_mask_v333_bi'
resume_model_path = ''
train_scenes = ['BistroInterior'] # Bistro BistroInterior Sponza BistroExterior EmeraldSquare
test_scenes = ['BistroInterior']
# spp0.25 is named as images
train_default_size = [1024, 2048] # [720, 1280] [1024, 2048]
test_default_size = [1024, 2048]
train_spp_dir = 'images'
test_spp_dir = 'images'
cache = True
data_repeat = 10
multi_gpu = False # torch.cuda.device_count() > 1
loss_weight = [0.05, 0.25, 0.5, 0.75, 1]

manual_random_seed = 42

# -----------logger--------------
logger = logging.getLogger('train')
# logger.setLevel(logging.INFO)
logger.setLevel(logging.DEBUG)

ch = logging.StreamHandler()
# ch.setLevel(logging.INFO)
ch.setLevel(logging.DEBUG)

formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

# ----------- Val logger--------------
val_logger = logging.getLogger('val')
val_logger.setLevel(logging.DEBUG)
