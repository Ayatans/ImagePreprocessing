import torch
import torch.nn as nn
import torch.nn.functional as F
import settings
from utils import save_output_exr

logger = settings.logger


class TemporalAccumulation(nn.Module):
    def __init__(self, in_channels=7):
        super(TemporalAccumulation, self).__init__()
        self.in_channels = in_channels
        self.temporal_attn1 = nn.Sequential(
            ConvBlock(in_channels, 32), 
            ConvBlock(32, 32)
        )
        self.temporal_attn2 = nn.Sequential(
            ConvBlock(in_channels, 32), 
            ConvBlock(32, 32)
        )

    def forward(self, current_x, previous_x, warped_mask, mask):
        """
        Args:
            current_x (Tensor): current frame features with shape (b, 7, h, w).
            previous_x (Tensor): previous frame features with shape (b, 7, h, w).
            mv (Tensor): motion vector of current frame (b, 2, h, w).

        Returns:
            Tensor: accumulated illumination (b, 3, h, w).
        """
        b, c, h, w = current_x.shape

        current_feats = torch.cat([current_x, mask], dim=1)
        prev_feats = torch.cat([previous_x, warped_mask], dim=1)

        ref_embedding = self.temporal_attn1(current_feats)
        # ref_embedding = torch.cat([ref_embedding, current_feats], dim=1)
        embedding = self.temporal_attn2(torch.cat([current_feats, prev_feats], dim=0))

        cur_embedding = embedding[0:b, ...]
        corr0 = torch.sum(cur_embedding * ref_embedding, 1) # (b, h, w)
        corr0 = corr0.unsqueeze(1)  # (b, 1, h, w)
        prev_embedding = embedding[b:, ...]
        corr1 = torch.sum(prev_embedding * ref_embedding, 1) # (b, h, w)
        corr1 = corr1.unsqueeze(1)  # (b, 1, h, w)

        alpha = F.softmax(torch.cat([corr0, corr1], dim=1), dim=1) # (b, 2, h, w)
        a1 = torch.mul(alpha[:, 1:, ...], previous_x)
        a2 = torch.mul(alpha[:, 0:1, ...], current_x)
        acc_x = a1 + a2

        beta = 1.0 / (alpha[:, 0:1, ...] + 0.001)

        acc_mask = torch.mul(alpha[:, 1:, ...], warped_mask) + torch.mul(alpha[:, 0:1, ...], mask)

        return acc_x, a1 * beta, a1, a2, alpha[:, 1:, ...], alpha[:, 0:1, ...], acc_mask

class ConvBlock(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(ConvBlock, self).__init__()
        self.in_channel=in_channel
        self.out_channel=out_channel
        self.block = nn.Sequential(
            nn.Conv2d(in_channel, out_channel, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        out = self.block(x)
        return out

    def flops(self, H, W): 
        flops = H*W*self.in_channel*self.out_channel*(3*3+1)+H*W*self.out_channel*self.out_channel*3*3
        return flops

class PyramidDenoisingNet(nn.Module):
    def  __init__(self, buffers_in_size, buffers_out_size):
        super().__init__()

        self.in_features = buffers_in_size
        self.out_features = buffers_out_size

        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')

        kern1_size = 3
        kern1_padding = 1

        def conv_unit(in_layers, out_layers):
            return nn.Sequential(
                nn.Conv2d(in_layers, out_layers, kern1_size, padding=kern1_padding),
                nn.LeakyReLU(negative_slope=0.1, inplace=True)
                )

        def convs(layers):
            units = []

            for idx in range(len(layers)-1):
                units.append(conv_unit(layers[idx], layers[idx+1]))

            return nn.Sequential(*units)

        def convs2(in_ch, our_ch):
            units = []

            down_layer = nn.Sequential(
                nn.Conv2d(in_channels=in_ch, out_channels=our_ch, kernel_size=3, stride=2, padding=1),
                nn.LeakyReLU(negative_slope=0.1, inplace=True)
                )
            conv_layer = nn.Sequential(
                nn.Conv2d(in_channels=our_ch, out_channels=our_ch, kernel_size=3, stride=1, padding=1),
                nn.LeakyReLU(negative_slope=0.1, inplace=True)
                )

            units.append(down_layer)
            units.append(conv_layer)
            return nn.Sequential(*units)

        self.encod0 = convs([self.in_features, 64, 64, 32])

        self.conv_feat_l2 = convs2(32, 64)
        self.conv_feat_l3 = convs2(64, 128)

        self.conv_acc_l2 = nn.AvgPool2d(kernel_size=3, stride=2, padding=1) #convs2(3, 3)
        self.conv_acc_l3 = nn.AvgPool2d(kernel_size=3, stride=2, padding=1) #convs2(3, 3)

        self.l3= convs([128+3, 128, 3])
        self.l2= convs([64+6, 64, 3])
        self.l1= convs([32+6, 32, 4])

        self.sigmoid = nn.Sigmoid()

    def forward(self, x, acc_x, debug=False, epoch=0, index=0, save_root_dir=None, step=0):
        feat_l1 = self.encod0(torch.cat([x, acc_x], dim=1))

        # L2
        feat_l2 = self.conv_feat_l2(feat_l1)
        acc_l2 = self.conv_acc_l2(acc_x)

        # L3
        feat_l3 = self.conv_feat_l3(feat_l2)
        acc_l3 = self.conv_acc_l3(acc_l2)

        # L3 out
        out_l3 = torch.cat([feat_l3, acc_l3], dim=1)
        out_l3 = self.l3(out_l3)
        upsample_l3 = self.upsample(out_l3)

        # L2 out
        out_l2 = torch.cat([feat_l2, acc_l2, upsample_l3], dim=1)
        out_l2 = self.l2(out_l2)
        upsample_l2 = self.upsample(out_l2)

        # L1 out
        out_l1 = torch.cat([feat_l1, acc_x, upsample_l2], dim=1)
        out_l1 = self.l1(out_l1)

        x_t = out_l1[:, :3, ...]
        alpha = self.sigmoid(out_l1[:, 3:, ...])

        if debug:
            prefix = 'epoch' + str(epoch) + '_' + 'idx' + str(index) + '_' + 'step' + str(step)

            save_output_exr(acc_l2[0, 0:3, ...], save_root_dir, prefix + '_acc_l2_illu')
            save_output_exr(acc_l3[0, 0:3, ...], save_root_dir, prefix + '_acc_l3_illu')

            save_output_exr(out_l3[0, 0:3, ...], save_root_dir, prefix + '_out_l3_illu')
            save_output_exr(out_l2[0, 0:3, ...], save_root_dir, prefix + '_out_l2_illu')

            alpha1 = torch.cat([alpha[0, ...], alpha[0, ...], alpha[0, ...]], dim=0)
            save_output_exr(alpha1, save_root_dir, prefix + '_alpha_t')

        ret = alpha * x_t + (1. - alpha) * acc_x

        return ret


class Network(nn.Module):
    def __init__(self):
        super(Network, self).__init__()
        self.previous_est = None
        self.history_mask = None
        self.mode = 'train'
        self.recursion_step = settings.recursion_step
        self.reconstruct = PyramidDenoisingNet(buffers_in_size=36, buffers_out_size=4)
        self.temporal_accumulation = TemporalAccumulation(in_channels=19)

    def warper2d(self, history, flow):
        h, w = history.size()[-2:]
        x_grid = torch.arange(0., w).to(history.device).float() + 0.5
        y_grid = torch.arange(0., h).to(history.device).float() + 0.5
        x_grid = (x_grid / w).view(1, 1, -1, 1).expand(1, h, -1, 1)  # 1, h, w, 1
        y_grid = (y_grid / h).view(1, -1, 1, 1).expand(1, -1, w, 1)  # 1, h, w, 1
        x_grid = x_grid * 2 - 1.
        y_grid = y_grid * 2 - 1.

        grid = torch.cat((x_grid, y_grid), dim=-1)  # b, h, w, 2
        flow = flow.permute(0, 2, 3, 1)  # b, h, w, 2

        # scale motion vector
        flow[..., 0:1] *= float(settings.train_default_size[1]) / float(w)
        flow[..., 1:2] *= float(settings.train_default_size[0]) / float(h)

        grid = grid - flow*2

        warped = F.grid_sample(history, grid, align_corners=True)
        return warped

    def train(self, mode=True):
        super().train(mode)
        if mode:
            self.mode = 'train'
            self.previous_est = None
            self.recursion_step = settings.recursion_step
        else:
            self.mode = 'test'
            self.previous_est = None
            self.recursion_step = 1
        return self

    def forward(self, inputs, debug=False, epoch=0, index=0, save_root_dir=None):
        irradiances = inputs['image']
        mvs = inputs['mv']
        depths = inputs['depth']
        normals = inputs['normal']
        albedos = inputs['albedo']
        pbrs = inputs['pbr']
        trans = inputs['tran']
        shadows = inputs['shadow']
        gts = inputs['gt']
        outputs = []
        acc_albedos = []

        for step in range(self.recursion_step):
            irradiance = irradiances[..., step]
            depth = depths[..., step]
            normal = normals[..., step]
            albedo = albedos[..., step]
            pbr = pbrs[..., step]
            tran = trans[..., step]
            shadow = shadows[..., step]
            gt = gts[..., step]
            mv = mvs[..., step]

            color_mask = torch.sum(irradiance, dim=1, keepdim=True)
            ones = torch.ones_like(color_mask)
            zeros = torch.zeros_like(color_mask)
            mask = torch.where(color_mask > 0.0, ones, zeros)

            x = torch.cat([irradiance, albedo, shadow, normal, depth, tran, pbr], dim=1)
            if self.mode == 'train' and step == 0 or self.previous_est == None:
                warped_feats = x
                warped_mask = mask
            else:
                warped_feats = self.warper2d(self.previous_est, mv)
                warped_mask = self.warper2d(self.history_mask, mv)

                #color_mask2 = torch.sum(warped_feats[:, 0:3, ...], dim=1, keepdim=True)
                #warped_mask = torch.where(color_mask2 > 0.0, ones, zeros)

            accumulated_x, a1, a1_raw, a2, alpha1, alpha2, acc_mask = self.temporal_accumulation(x, warped_feats, warped_mask, mask)
            all_features = torch.cat([x[:, 3:, ...], accumulated_x], dim=1)
            denoised_img = self.reconstruct(all_features, warped_feats[:, 0:3, ...], debug, epoch, index, save_root_dir, step) # warped_feats: replace with accumulated_x

            if debug:
                prefix = 'epoch' + str(epoch) + '_' + 'idx' + str(index) + '_' + 'step' + str(step)

                save_output_exr(x[0, 0:3, ...], save_root_dir, prefix + '_curr_illu')
                save_output_exr(accumulated_x[0, 0:3, ...], save_root_dir, prefix + '_acc_illu')
                save_output_exr(warped_feats[0, 0:3, ...], save_root_dir, prefix + '_warped_illu')

                save_output_exr(x[0, 9:12, ...], save_root_dir, prefix + '_curr_n')
                save_output_exr(accumulated_x[0, 9:12, ...], save_root_dir, prefix + '_acc_n')

                depth1 = torch.cat([x[0, 12:13, ...], x[0, 12:13, ...], x[0, 12:13, ...]], dim=0)
                save_output_exr(depth1, save_root_dir, prefix + '_curr_depth')
                depth2 = torch.cat([accumulated_x[0, 12:13, ...], accumulated_x[0, 12:13, ...], accumulated_x[0, 12:13, ...]], dim=0)
                save_output_exr(depth2, save_root_dir, prefix + '_acc_depth')

                save_output_exr(x[0, 13:16, ...], save_root_dir, prefix + '_curr_tran')
                save_output_exr(accumulated_x[0, 13:16, ...], save_root_dir, prefix + '_acc_tran')

                roughness1 = torch.cat([x[0, 16:17, ...], x[0, 16:17, ...], x[0, 16:17, ...]], dim=0)
                save_output_exr(roughness1, save_root_dir, prefix + '_curr_roughness')
                roughness2 = torch.cat([accumulated_x[0, 16:17, ...], accumulated_x[0, 16:17, ...], accumulated_x[0, 16:17, ...]], dim=0)
                save_output_exr(roughness2, save_root_dir, prefix + '_acc_roughness')

                metallic1 = torch.cat([x[0, 17:18, ...], x[0, 17:18, ...], x[0, 17:18, ...]], dim=0)
                save_output_exr(metallic1, save_root_dir, prefix + '_curr_metallic')
                metallic2 = torch.cat([accumulated_x[0, 17:18, ...], accumulated_x[0, 17:18, ...], accumulated_x[0, 17:18, ...]], dim=0)
                save_output_exr(metallic2, save_root_dir, prefix + '_acc_metallic')

                save_output_exr(a1[0, 0:3, ...], save_root_dir, prefix + '_a1')
                save_output_exr(a1_raw[0, 0:3, ...], save_root_dir, prefix + '_a1_raw')
                save_output_exr(a2[0, 0:3, ...], save_root_dir, prefix + '_a2')

                alpha1_1 = torch.cat([alpha1[0, ...], alpha1[0, ...], alpha1[0, ...]], dim=0)
                alpha2_1 = torch.cat([alpha2[0, ...], alpha2[0, ...], alpha2[0, ...]], dim=0)
                acc_mask1 = torch.cat([acc_mask[0, ...], acc_mask[0, ...], acc_mask[0, ...]], dim=0)
                color_mask1 = torch.cat([mask[0, ...], mask[0, ...], mask[0, ...]], dim=0)
                warp_mask1 = torch.cat([warped_mask[0, ...], warped_mask[0, ...], warped_mask[0, ...]], dim=0)

                save_output_exr(alpha1_1, save_root_dir, prefix + '_alpha1')
                save_output_exr(alpha2_1, save_root_dir, prefix + '_alpha2')
                save_output_exr(acc_mask1, save_root_dir, prefix + '_acc_mask')
                save_output_exr(color_mask1, save_root_dir, prefix + '_color_mask')
                save_output_exr(warp_mask1, save_root_dir, prefix + '_warp_mask')

                save_output_exr(x[0, 3:6, ...], save_root_dir, prefix + '_curr_albedo')          
                save_output_exr(accumulated_x[0, 3:6, ...], save_root_dir, prefix + '_acc_albedo')
                # save_output_exr(warped_feats[0, 3:6, ...], save_root_dir, prefix + '_warped_albedo')

                save_output_exr(x[0, 6:9, ...], save_root_dir, prefix + '_curr_shadow')
                save_output_exr(accumulated_x[0, 6:9, ...], save_root_dir, prefix + '_acc_shadow')

                save_output_exr(denoised_img[0, ...], save_root_dir, prefix + '_denoised')
                save_output_exr(gt[0, ...], save_root_dir, prefix + '_gt')

            self.previous_est = torch.cat([denoised_img, accumulated_x[:, 3:, ...]], dim=1)
            self.history_mask = acc_mask

            acc_albedos.append(accumulated_x[:, 3:6, ...])
            outputs.append(denoised_img)
        
        acc_albedos = torch.stack(acc_albedos, dim=-1)
        outputs = torch.stack(outputs, dim=-1)
        
        return outputs, acc_albedos

